package com.example.grocery_app.Helper;

public interface ChangeNumberItemsListener {
    void change();
}
